<main>
    <div>
    <div class="bg-light py-3">
          <div class="container">
            <div class="row">
              <div class="col-md-12 mb-0"><a href="/">Home</a> <span class="mx-2 mb-0">/</span> <strong class="text-black">Category</strong> <span class="mx-2 mb-0">/</span> <strong class="text-black">{{$category_name}}</strong></div>
            </div>
          </div>
        </div>
    
        <div class="site-section">
          <div class="container">
    
            <div class="row mb-5">
              <div class="col-md-9 order-2">
    
                <div class="row">
                  <div class="col-md-12 mb-5">
                    <div class="float-md-left mb-4"><h2 class="text-black h5">Shop All</h2></div>
                    <div class="d-flex">
                      <div class="dropdown mr-1 ml-md-auto">
    
                        <select wire:model="sorting" class="btn btn-outline-primary btn-sm" >
                          <option value="default" selected >Default</option>
                          <option value="date">New</option>
                          <option value="priceI">Price Low to high</option>
                          <option value="priceD">Price High to Low</option>
                        </select>
    
                        <select wire:model="pagesize" class="btn btn-outline-primary btn-sm">
                          <option value="9" selected>9</option>
                          <option value="14" >14</option>
                        </select>
                      </div>
    
                    </div>
                  </div>
                </div>
                @if($products->count()>0)
                <div class="row mb-5">
                  @php
                  $witems = Cart::instance('wishlist')->content()->pluck('id');
                  @endphp
                  @foreach ($products as $product)
                  
                  <div class="col-sm-6 col-lg-4 mb-4" data-aos="fade-up">
                    <div class="block-4 text-center border">
                      <figure class="block-4-image">
                        <a href="{{route('product.details',['slug'=>$product->slug])}}"><img src="{{asset ('images')}}/{{$product->image}}" alt="{{$product->name}}" class="img-fluid"></a>
                      </figure>
                      <div class="block-4-text p-4">
                        <h3><a href="{{route('product.details',['slug'=>$product->slug])}}">{{$product->name}}</a></h3>
                        <p class="mb-0">{{$product->short_description}}</p>
                        @if($product->stock_status == 'instock' && $product->sale_price > 0)
                        <label class="text-primary font-weight-bold"><del>${{$product->regular_price}}</del></label><br>
                        <label class="text-primary font-weight-bold">${{$product->sale_price}}</label><br>
                        <a href="#" class="btn btn-outline-primary" wire:click.prevent="store({{$product->id}},'{{$product->name}}',{{$product->sale_price}})"><small>Add to Cart</small></a>
                        @elseif ($product->stock_status == 'instock' && $product->sale_price == 0)
                        <p class="text-primary font-weight-bold">${{$product->regular_price}}</p>
                        <a href="#" class="btn btn-outline-primary" wire:click.prevent="store({{$product->id}},'{{$product->name}}',{{$product->regular_price}})"><small>Add to Cart</small></a>
                        @elseif($product->stock_status == 'outofstock' && $product->sale_price > 0)
                        <label class="text-primary font-weight-bold"><del>${{$product->regular_price}}</del></label><br>
                        <label class="text-primary font-weight-bold">${{$product->sale_price}}</label><br>
                        <span class="text-danger">Out of Stock</span><br>
                        <a href="#" class="btn btn-outline-primary disabled"><small>Add to Cart</small></a>
                        @elseif ($product->stock_status == 'outofstock' && $product->sale_price == 0)
                        <span class="text-primary font-weight-bold">${{$product->regular_price}}</span><br>
                        <span class="text-danger">Out of Stock</span><br>
                        <a href="#" class="btn btn-outline-primary disabled"><small>Add to Cart</small></a>
                        @endif
                        @if($product->sale_price > 0)
                        <div class="product-wish">
                          @if($witems->contains($product->id))
                          <a href="#" wire:click.prevent="removeFromWishlist({{$product->id}})"><i class="fa fa-heart fill-heart"></i></a>
                          @else
                          <a href="#" wire:click.prevent="addToWishlist({{$product->id}},'{{$product->name}}',{{$product->sale_price}})"><i class="fa fa-heart"></i></a>
                          @endif
                        </div>
                        @else
                          <div class="product-wish">
                          @if($witems->contains($product->id))
                          <a href="#" wire:click.prevent="removeFromWishlist({{$product->id}})"><i class="fa fa-heart fill-heart"></i></a>
                          @else
                          <a href="#" wire:click.prevent="addToWishlist({{$product->id}},'{{$product->name}}',{{$product->regular_price}})"><i class="fa fa-heart"></i></a>
                          @endif
                          </div>
                        @endif
                      </div>
                    </div>
                  </div>
                  @endforeach
                </div>
                @else
                <p class="text-center h4">No Products found</p>
                @endif
                <div class="row" data-aos="fade-up">
                  <div class="col-md-12 text-center">
                    <div class="wrap-pagination-info" >
                      {{$products->links()}}
                    </div>
                  </div>
                </div>
              </div>
    
              <div class="col-md-3 order-1 mb-5 mb-md-0">
                <div class="border p-4 rounded mb-4">
                  <h3 class="mb-3 h6 text-uppercase text-black d-block">Categories</h3>
                  <ul class="list-unstyled mb-0">
                    @foreach ($categories as $category)
                    <li class="mb-1"><a href="{{route('product.category',['category_slug'=>$category->slug])}}" class="d-flex"><span>{{$category->name}}</span> <span class="text-black ml-auto"></span></a></li>
                    @endforeach
                  </ul>
                </div>
    
                <div class="border p-4 rounded mb-4">
                  <!--<div class="mb-4">
                    <h3 class="mb-3 h6 text-uppercase text-black d-block">Filter by Price</h3>
                    <div id="slider-range" class="border-primary"></div>
                    <input type="text" name="text" id="amount" class="form-control border-0 pl-0 bg-white" disabled="" />
                  </div>-->
    
                  <div class="mb-4">
                    <h3 class="mb-3 h6 text-uppercase text-black d-block">Size</h3>
                    <label for="s_sm" class="d-flex">
                      <input type="checkbox" id="s_sm" class="mr-2 mt-1"> <span class="text-black">Small (2,319)</span>
                    </label>
                    <label for="s_md" class="d-flex">
                      <input type="checkbox" id="s_md" class="mr-2 mt-1"> <span class="text-black">Medium (1,282)</span>
                    </label>
                    <label for="s_lg" class="d-flex">
                      <input type="checkbox" id="s_lg" class="mr-2 mt-1"> <span class="text-black">Large (1,392)</span>
                    </label>
                  </div>
    
                  <div class="mb-4">
                    <h3 class="mb-3 h6 text-uppercase text-black d-block">Color</h3>
                    <a href="#" class="d-flex color-item align-items-center" >
                      <span class="bg-danger color d-inline-block rounded-circle mr-2"></span> <span class="text-black">Red (2,429)</span>
                    </a>
                    <a href="#" class="d-flex color-item align-items-center" >
                      <span class="bg-success color d-inline-block rounded-circle mr-2"></span> <span class="text-black">Green (2,298)</span>
                    </a>
                    <a href="#" class="d-flex color-item align-items-center" >
                      <span class="bg-info color d-inline-block rounded-circle mr-2"></span> <span class="text-black">Blue (1,075)</span>
                    </a>
                    <a href="#" class="d-flex color-item align-items-center" >
                      <span class="bg-primary color d-inline-block rounded-circle mr-2"></span> <span class="text-black">Purple (1,075)</span>
                    </a>
                  </div>
    
                </div>
              </div>
            </div>
    
            <div class="row">
              <div class="col-md-12">
                <div class="site-section site-blocks-2">
                    <div class="row justify-content-center text-center mb-5">
                      <div class="col-md-7 site-section-heading pt-4">
                        <h2>Categories</h2>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-sm-6 col-md-6 col-lg-4 mb-4 mb-lg-0" data-aos="fade" data-aos-delay="">
                        <a class="block-2-item" href="#">
                          <figure class="image">
                            <img src="{{asset ('images/women.jpg')}}" alt="" class="img-fluid">
                          </figure>
                          <div class="text">
                            <span class="text-uppercase">Collections</span>
                            <h3>Women</h3>
                          </div>
                        </a>
                      </div>
                      <div class="col-sm-6 col-md-6 col-lg-4 mb-5 mb-lg-0" data-aos="fade" data-aos-delay="100">
                        <a class="block-2-item" href="#">
                          <figure class="image">
                            <img src="{{asset ('images/children.jpg')}}" alt="" class="img-fluid">
                          </figure>
                          <div class="text">
                            <span class="text-uppercase">Collections</span>
                            <h3>Children</h3>
                          </div>
                        </a>
                      </div>
                      <div class="col-sm-6 col-md-6 col-lg-4 mb-5 mb-lg-0" data-aos="fade" data-aos-delay="200">
                        <a class="block-2-item" href="#">
                          <figure class="image">
                            <img src="{{asset ('images/men.jpg')}}" alt="" class="img-fluid">
                          </figure>
                          <div class="text">
                            <span class="text-uppercase">Collections</span>
                            <h3>Men</h3>
                          </div>
                        </a>
                      </div>
                    </div>
                  
                </div>
              </div>
            </div>
            
          </div>
        </div>
    </main>
    