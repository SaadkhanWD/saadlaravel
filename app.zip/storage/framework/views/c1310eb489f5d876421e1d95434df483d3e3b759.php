<div>
    <h1>This is user dashboard</h1>
</div>
<?php /**PATH D:\xampp\htdocs\laravelecommerce\resources\views/livewire/user/user-dashboard-component.blade.php ENDPATH**/ ?>