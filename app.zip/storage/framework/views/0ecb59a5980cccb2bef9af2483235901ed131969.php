<main>
<div class="container mt-5 mb-5">
    <div class="row">
    <div class="col-md-3">
      <div class="card-counter primary">
        <i class="fas fa-chart-pie"></i>
        <span class="count-numbers">$<?php echo e($totalRevenue); ?></span>
        <span class="count-name">Total Revenue</span>
      </div>
    </div>

    <div class="col-md-3">
      <div class="card-counter danger">
        <i class="fas fa-cash-register"></i>
        <span class="count-numbers"><?php echo e($totalSales); ?></span>
        <span class="count-name">Total Sales</span>
      </div>
    </div>

    <div class="col-md-3">
      <div class="card-counter success">
        <i class="fas fa-hand-holding-usd"></i>
        <span class="count-numbers">$<?php echo e($todayRevenue); ?></span>
        <span class="count-name">Today's Revenue</span>
      </div>
    </div>

    <div class="col-md-3">
      <div class="card-counter info">
        <i class="fas fa-donate"></i>
        <span class="count-numbers"><?php echo e($todaySales); ?></span>
        <span class="count-name">Today's Sales</span>
      </div>
    </div>
  </div>
</div>

<div>
    <style>
        nav svg{
            height: 20px;
        }
        nav .hidden{
            display:block !important;
        }
    </style>
    <div class="container" >
        <?php if(Session::has('order_message')): ?>
        <div class="alert alert-info" role="alert"><?php echo e(Session::get('order_message')); ?></div>
        <?php endif; ?>
        <div class="row">
            <div class="col-md-12">
                <div class="card mt-3">
                    <div class="card-header">
                        <div class="row">
                            <div class="col-md-6 h6 mt-3">
                                Latest Orders
                            </div>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Order Id</th>
                                    <th>First Name</th>
                                    <th>Last Name</th>
                                    <th>Mobile</th>
                                    <th>Email</th>
                                    <th>Zipcode</th>
                                    <th>Subtotal</th>
                                    <th>Discount</th>
                                    <th>Tax</th>
                                    <th>Total</th>
                                    <th>Status</th>
                                    <th>Order Date</th>
                                    <th colspan="2" class="text-center">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($order->id); ?></td>
                                    <td><?php echo e($order->firstname); ?></td>
                                    <td><?php echo e($order->lastname); ?></td>
                                    <td><?php echo e($order->mobile); ?></td>
                                    <td><?php echo e($order->email); ?></td>
                                    <td><?php echo e($order->zipcode); ?></td>
                                    <td>$<?php echo e($order->subtotal); ?></td>
                                    <td>$<?php echo e($order->discount); ?></td>
                                    <td>$<?php echo e($order->tax); ?></td>
                                    <td>$<?php echo e($order->total); ?></td>     
                                    <?php if($order->status == 'ordered'): ?>
                                    <td class="text-warning font-weight-bold"><?php echo e($order->status); ?></td>
                                    <?php elseif($order->status == 'delivered'): ?>
                                    <td class="text-success font-weight-bold"><?php echo e($order->status); ?></td>
                                    <?php elseif($order->status == 'canceled'): ?>
                                    <td class="text-danger font-weight-bold"><?php echo e($order->status); ?></td>
                                    <?php elseif($order->status == 'shipped'): ?>
                                    <td class="text-primary font-weight-bold"><?php echo e($order->status); ?></td>
                                    <?php endif; ?>
                                    <td><?php echo e($order->created_at); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('admin.orderdetails',['order_id'=>$order->id])); ?>" class="btn btn-outline-primary btn-sm"><small>Details</small></a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

</main><?php /**PATH D:\xampp\htdocs\laravelecommerce\resources\views/livewire/admin/admin-dashboard-component.blade.php ENDPATH**/ ?>