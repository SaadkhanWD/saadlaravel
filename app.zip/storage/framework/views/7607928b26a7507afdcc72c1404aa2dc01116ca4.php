<a href="/cart" class="site-cart">
    <span class="icon icon-shopping_cart"></span>
    <?php if(Cart::instance('cart')->count() > 0): ?>
    <span class="count"><?php echo e(Cart::instance('cart')->count()); ?></span>
    <?php endif; ?>
</a>
<?php /**PATH D:\xampp\htdocs\laravelecommerce\resources\views/livewire/cart-count-component.blade.php ENDPATH**/ ?>