<a href="/shop">Categories</a>
<ul class="dropdown">
  <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
  <li><a href="<?php echo e(route('product.category',['category_slug'=>$category->slug])); ?>"><?php echo e($category->name); ?></a></li>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php /**PATH D:\xampp\htdocs\laravelecommerce\resources\views/livewire/catalogue-component.blade.php ENDPATH**/ ?>