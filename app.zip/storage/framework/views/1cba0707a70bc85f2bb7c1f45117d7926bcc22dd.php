<div>
    <div>
        <div>
            <style>
                nav svg{
                    height: 20px;
                }
                nav .hidden{
                    display:block !important;
                }
            </style>
            <div class="container" >
                <?php if(Session::has('message')): ?>
                <div class="alert alert-danger" role="alert"><?php echo e(Session::get('message')); ?></div>
                <?php endif; ?>

                <div class="row">
                  <div class="col-md-12">
                      <div class="card mt-3">
                          <div class="card-header">
                              <div class="row">
                                  <div class="col-md-6 h6 mt-3">
                                      Order Status
                                  </div>
                                  <div class="col-md-6">
                                    <a href="<?php echo e(route('admin.orders')); ?>" class="btn btn-outline-primary btn-sm float-right">All Orders</a>
                                </div>
                              </div>
                          </div>
                          <div class="table-responsive p-3">
                              <table class="table table-striped">
                                <tr>
                                  <th>Order Id</th>
                                  <td><?php echo e($order->id); ?></td>
                                  <th>Order Date</th>
                                  <td><?php echo e($order->created_at); ?></td>
                                  <th>Order Status</th>
                                  <?php if($order->status == 'ordered'): ?>
                                  <td class="text-warning font-weight-bold"><?php echo e($order->status); ?></td>
                                  <?php elseif($order->status == 'delivered'): ?>
                                  <td class="text-success font-weight-bold"><?php echo e($order->status); ?></td>
                                  <?php elseif($order->status == 'canceled'): ?>
                                  <td class="text-danger font-weight-bold"><?php echo e($order->status); ?></td>
                                  <?php elseif($order->status == 'shipped'): ?>
                                  <td class="text-primary font-weight-bold"><?php echo e($order->status); ?></td>
                                  <?php endif; ?>
                                  <?php if($order->status == 'delivered'): ?>
                                  <th>Delivered Date</th>
                                  <td><?php echo e($order->delivered_date); ?></td>
                                  <?php elseif($order->status == 'canceled'): ?>
                                  <th>Cancel Date</th>
                                  <td><?php echo e($order->canceled_date); ?></td>
                                  <?php elseif($order->status == 'shipped'): ?>
                                  <th>Shipped Date</th>
                                  <td><?php echo e($order->shipped_date); ?></td>
                                  <?php endif; ?>
                                </tr>
                              </table>
                          </div>
                      </div>
                  </div>
              </div>

                <div class="row">
                    <div class="col-md-12">
                        <div class="card mt-3">
                            <div class="card-header">
                                <div class="row">
                                    <div class="col-md-6 h6 mt-3">
                                        Ordered Items
                                    </div>
                                </div>
                            </div>
                            <div class="site-blocks-table">
                                <table class="table table-bordered">
                                    <thead>
                                      <tr>
                                        <th class="product-thumbnail">Image</th>
                                        <th class="product-name">Product</th>
                                        <th class="product-quantity">Quantity</th>
                                        <th class="product-total">SubTotal</th>
                                      </tr>
                                    </thead>
                                    <tbody>
                                      <?php $__currentLoopData = $order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <tr>
                                        <td class="product-thumbnail">
                                          <img src="<?php echo e(asset ('images')); ?>/<?php echo e($item->product->image); ?>" alt="<?php echo e($item->product->name); ?>" class="img-fluid">
                                        </td>
                                        <td class="product-name">
                                          <h2 class="h5 text-black" href="<?php echo e(route('product.details',['slug'=>$item->product->slug])); ?>"><?php echo e($item->product->name); ?></h2>
                                        </td>
                                        <td>
                                          <label class="h5"><?php echo e($item->quantity); ?></label>
                                        </td>
                                        <td class="h5">$<?php echo e($item->price * $item->quantity); ?></td>
                                      </tr>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                  </table>
                            </div>
                            <label class="text-center h3 mt-3 mb-2">Order Summary</label><hr>
                            <div class="container">
                              <div class="col-md-12">
                                <div class="row justify-content-end">
                                  <div class="col-md-12">
                                    <div class="row mb-3">
                                      <div class="col-md-6">
                                        <span class="text-black h6">Discount</span>
                                      </div>
                                       <div class="col-md-6 text-right">
                                        <strong class="text-danger h6">-$<?php echo e($order->discount); ?></strong>
                                       </div>
                                    </div><hr>
                                <div class="row mb-3">
                                    <div class="col-md-6">
                                      <span class="text-black h6">Subtotal<small> (After Discount)</small></span>
                                    </div>
                                     <div class="col-md-6 text-right">
                                      <strong class="text-black h6">$<?php echo e($order->subtotal); ?></strong>
                                     </div>
                                  </div><hr>
                                  <div class="row mb-3">
                                    <div class="col-md-6">
                                      <span class="text-black h6">Tax</span>
                                    </div>
                                    <div class="col-md-6 text-right">
                                        <strong class="text-black h6">$<?php echo e($order->tax); ?></strong>
                                    </div>
                                  </div><hr>
                                  <div class="row mb-3">
                                    <div class="col-md-6">
                                      <span class="text-black h6">Total</span>
                                    </div>
                                    <div class="col-md-6 text-right">
                                        <strong class="text-black h6">$<?php echo e($order->total); ?></strong>
                                    </div>
                                  </div>
                                  </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <div class="row">
              <div class="col-md-12">
                  <div class="card mt-3">
                      <div class="card-header">
                          <div class="row">
                              <div class="col-md-6 h6 mt-3">
                                  Billing Details
                              </div>
                          </div>
                      </div>
                      <div class="table-responsive p-3">
                          <table class="table table-striped">
                            <tr>
                              <th>First Name</th>
                              <td><?php echo e($order->firstname); ?></td>
                              <th>Last Name</th>
                              <td><?php echo e($order->lastname); ?></td>
                            </tr>
                            <tr>
                              <th>Phone</th>
                              <td><?php echo e($order->mobile); ?></td>
                              <th>Email</th>
                              <td><?php echo e($order->email); ?></td>
                            </tr>
                            <tr>
                              <th>Address</th>
                              <td><?php echo e($order->line1); ?></td>
                              <th>Line 2</th>
                              <td><?php echo e($order->line2); ?></td>
                            </tr>
                            <tr>
                              <th>City</th>
                              <td><?php echo e($order->city); ?></td>
                              <th>Province</th>
                              <td><?php echo e($order->province); ?></td>
                            </tr>
                            <tr>
                              <th>Country</th>
                              <td><?php echo e($order->country); ?></td>
                              <th>Zipcode</th>
                              <td><?php echo e($order->zipcode); ?></td>
                            </tr>
                          </table>
                      </div>
                  </div>
              </div>
          </div>

          <?php if($order->is_shipping_different): ?>
          <div class="row">
            <div class="col-md-12">
                <div class="card mt-3">
                    <div class="card-header">
                        <div class="row">
                            <div class="col-md-6 h6 mt-3">
                                Shipping Details
                            </div>
                        </div>
                    </div>
                    <div class="table-responsive p-3">
                        <table class="table table-striped">
                          <tr>
                            <th>First Name</th>
                            <td><?php echo e($order->shipping->firstname); ?></td>
                            <th>Last Name</th>
                            <td><?php echo e($order->shipping->lastname); ?></td>
                          </tr>
                          <tr>
                            <th>Phone</th>
                            <td><?php echo e($order->shipping->mobile); ?></td>
                            <th>Email</th>
                            <td><?php echo e($order->shipping->email); ?></td>
                          </tr>
                          <tr>
                            <th>Address</th>
                            <td><?php echo e($order->shipping->line1); ?></td>
                            <th>Line 2</th>
                            <td><?php echo e($order->shipping->line2); ?></td>
                          </tr>
                          <tr>
                            <th>City</th>
                            <td><?php echo e($order->shipping->city); ?></td>
                            <th>Province</th>
                            <td><?php echo e($order->shipping->province); ?></td>
                          </tr>
                          <tr>
                            <th>Country</th>
                            <td><?php echo e($order->shipping->country); ?></td>
                            <th>Zipcode</th>
                            <td><?php echo e($order->shipping->zipcode); ?></td>
                          </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <div class="row">
          <div class="col-md-12">
              <div class="card mt-3">
                  <div class="card-header">
                      <div class="row">
                          <div class="col-md-6 h6 mt-3">
                              Transaction Details
                          </div>
                      </div>
                  </div>
                  <div class="table-responsive p-3">
                      <table class="table table-bordered">
                        <tr>
                          <th>Transaction Mode</th>
                          <td><?php echo e($order->transaction->mode); ?></td>
                        </tr>
                        <tr>
                          <th>Status</th>
                          <td><?php echo e($order->transaction->status); ?></td>
                        </tr>
                        <tr>
                          <th>Transaction Date</th>
                          <td><?php echo e($order->transaction->created_at); ?></td>
                        </tr>
                      </table>
                  </div>
              </div>
          </div>
      </div>

        </div>
    </div>
</div>
<?php /**PATH D:\xampp\htdocs\laravelecommerce\resources\views/livewire/admin/admin-order-details-component.blade.php ENDPATH**/ ?>