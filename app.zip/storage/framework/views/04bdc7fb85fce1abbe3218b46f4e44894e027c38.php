<main>
  
    <div class="bg-light py-3">
          <div class="container">
            <div class="row">
              <div class="col-md-12 mb-0"><a href="index.html">Home</a> <span class="mx-2 mb-0">/</span> <strong class="text-black">Wishlist</strong></div>
            </div>
          </div>
    </div><br>
    <div class="container">
        <?php if(Cart::instance('wishlist')->content()->count() > 0): ?>
    <div class="row mb-5">
        <?php $__currentLoopData = Cart::instance('wishlist')->content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-sm-6 col-lg-4 mb-4" data-aos="fade-up">
          <div class="block-4 text-center border">
            <figure class="block-4-image">
              <a href="<?php echo e(route('product.details',['slug'=>$item->model->slug])); ?>"><img src="<?php echo e(asset ('images')); ?>/<?php echo e($item->model->image); ?>" alt="<?php echo e($item->model->name); ?>" class="img-fluid"></a>
            </figure>
            <div class="block-4-text p-4">
              <h3><a href="<?php echo e(route('product.details',['slug'=>$item->model->slug])); ?>"><?php echo e($item->model->name); ?></a></h3>
              <p class="mb-0"><?php echo e($item->model->short_description); ?></p>
              <a href="#" class="btn btn-outline-primary mt-3" wire:click.prevent="moveProductFromWishlistToCart('<?php echo e($item->rowId); ?>')"><small>Remove from Wishlist</small></a>
              <div class="product-wish">
                <a href="#" wire:click.prevent="removeFromWishlist(<?php echo e($item->model->id); ?>)"><i class="fa fa-heart fill-heart"></i></a>
              </div>
            </div>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php else: ?>
        <p class="h3 text-center mt-4 mb-5">No Items in Wishlist</p>
        <?php endif; ?>
      </div>
</main>    
<?php /**PATH D:\xampp\htdocs\laravelecommerce\resources\views/livewire/wishlist-component.blade.php ENDPATH**/ ?>