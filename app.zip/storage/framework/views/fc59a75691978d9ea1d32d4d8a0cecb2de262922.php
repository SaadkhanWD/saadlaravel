<a href="<?php echo e(route('product.wishlist')); ?>" class="site-cart">
    <span class="icon icon-heart-o"></span>
    <?php if(Cart::instance('wishlist')->count() > 0): ?>
    <span class="count"><?php echo e(Cart::instance('wishlist')->count()); ?></span>
    <?php endif; ?>
</a>
<?php /**PATH D:\xampp\htdocs\laravelecommerce\resources\views/livewire/wishlist-count-component.blade.php ENDPATH**/ ?>