<div>
    <div class="container">
        <?php if(Session::has('message')): ?>
        <div class="alert alert-success" role="alert"><?php echo e(Session::get('message')); ?></div>
        <?php endif; ?>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="row">
                            <div class="col-md-6 ">
                                <label class="lead">Edit Category</label> 
                            </div>
                            <div class="col-md-6">
                                <a href="<?php echo e(route('admin.categories')); ?>" class="btn btn-primary btn-sm float-right">All categories</a>
                            </div>
                        </div>
                    </div>
                    <div>
                        <div class="row">
                        <div class="col-md-4"></div>
                        <form class="col-md-4 mt-3 mb-3" wire:submit.prevent="updateCategory">
                            <div class="form-group">
                            <label class="lead">Category Name</label>
                            <input type="text" class="form-control input-md" placeholder="Name" wire:model="name" wire:keyup="generateslug"/>
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group">
                            <label class="lead">Category Slug</label>
                            <input type="text" class="form-control input-md" placeholder="Slug" wire:model="slug"/>
                            <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                            <button type="submit" class="btn btn-outline-primary float-center">Update</button>
                            </div>

                        </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php /**PATH D:\xampp\htdocs\laravelecommerce\resources\views/livewire/admin/admin-edit-category-component.blade.php ENDPATH**/ ?>