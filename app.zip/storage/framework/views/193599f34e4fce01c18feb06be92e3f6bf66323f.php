<div>
    <div class="container" >
        <?php if(Session::has('message')): ?>
        <div class="alert alert-danger" role="alert"><?php echo e(Session::get('message')); ?></div>
        <?php endif; ?>
        <div class="row">
            <div class="col-md-12">
                <div class="card mt-3">
                    <div class="card-header">
                        <div class="row">
                            <div class="col-md-6 h6 mt-3">
                                All Coupons
                            </div>
                            <div class="col-md-6">
                                <a href="<?php echo e(route('admin.addcoupon')); ?>" class="btn btn-outline-primary btn-sm float-right">Add New</a>
                            </div>
                        </div>
                    </div>
                    <div>
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Coupon Code</th>
                                    <th>Coupon Type</th>
                                    <th>Coupon Value</th>
                                    <th>Cart Value</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($coupon->id); ?></td>
                                    <td><?php echo e($coupon->code); ?></td>
                                    <td><?php echo e($coupon->type); ?></td>
                                    <?php if($coupon->type == 'fixed'): ?>
                                        <td>$<?php echo e($coupon->value); ?></td>
                                    <?php else: ?>
                                        <td><?php echo e($coupon->value); ?>%</td>
                                    <?php endif; ?>
                                    <td><?php echo e($coupon->cart_value); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('admin.editcoupon',['coupon_id'=>$coupon->id])); ?>"> <i class="fa fa-edit fa-2x"></i>Edit</a>
                                        <a href="#" onclick="confirm('Are you sure you want to delete this Coupon?') || event.stopImmediatePropagation()" wire:click.prevent="deleteCoupon(<?php echo e($coupon->id); ?>)" class="ml-3"><i class="fa fa-times fa-2x text-danger"></i> </a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php /**PATH D:\xampp\htdocs\laravelecommerce\resources\views/livewire/admin/admin-coupon-component.blade.php ENDPATH**/ ?>